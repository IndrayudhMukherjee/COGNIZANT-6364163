class Product
{
    public int ProductId;
    public string ProductName;
    public string Category;
}
