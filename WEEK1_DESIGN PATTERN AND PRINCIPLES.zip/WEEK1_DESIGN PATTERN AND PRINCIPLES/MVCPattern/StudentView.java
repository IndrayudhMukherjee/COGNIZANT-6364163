package MVCPattern;

class StudentView {
    public void displayStudentDetails(String name, String id, String grade) {
        System.out.println("Student: " + name + " | ID: " + id + " | Grade: " + grade);
    }
}
