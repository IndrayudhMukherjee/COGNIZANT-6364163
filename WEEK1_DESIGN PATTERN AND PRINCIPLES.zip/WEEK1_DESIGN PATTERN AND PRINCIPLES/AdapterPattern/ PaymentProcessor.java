package AdapterPattern;

interface  PaymentProcessor {
    void processPayment(double amount);
}
    

