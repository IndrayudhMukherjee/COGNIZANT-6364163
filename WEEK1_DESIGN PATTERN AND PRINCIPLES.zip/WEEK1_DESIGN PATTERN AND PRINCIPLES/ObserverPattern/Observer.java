package ObserverPattern;

 interface Observer {
    void update(String stockSymbol, double price);
}
