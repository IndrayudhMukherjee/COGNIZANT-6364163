package  ProxyPattern;

interface Image {
    void display();
}
