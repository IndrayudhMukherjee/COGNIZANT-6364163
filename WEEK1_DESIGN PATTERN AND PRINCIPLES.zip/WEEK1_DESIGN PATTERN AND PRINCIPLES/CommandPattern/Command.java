package CommandPattern;

///////////////////////////////
// Exercise 9: Command Pattern
///////////////////////////////

interface Command {
    void execute();
}
