

///////////////////////////////
// Exercise 5: Decorator Pattern
///////////////////////////////

package  DecoratorPattern;

interface Notifier {
    void send();
}