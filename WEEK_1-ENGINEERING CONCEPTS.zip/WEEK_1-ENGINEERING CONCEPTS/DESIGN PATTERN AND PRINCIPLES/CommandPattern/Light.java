package CommandPattern;

class Light {
    public void turnOn() {
        System.out.println("Light turned ON....YAH SHOULD STUDY");
    }

    public void turnOff() {
        System.out.println("Light turned OFF....NO REELS, GO TO SLEEP");
    }
}
