
// File: Document.java
package FactoryMethodPatternExample;

public interface Document {
    void open();
}
