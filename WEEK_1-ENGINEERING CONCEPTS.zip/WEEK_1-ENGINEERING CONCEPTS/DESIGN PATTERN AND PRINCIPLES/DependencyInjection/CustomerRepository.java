package DependencyInjection;

interface CustomerRepository {
    String findCustomerById(String id);
}